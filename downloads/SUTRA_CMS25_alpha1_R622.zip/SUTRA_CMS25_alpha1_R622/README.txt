This is the basic install of the Sutra CMS. It includes the MIT open source modules for all the CMS functionality.

It does not come with an application framework to take care of windowing, navigation, searching, etc. These modules are meant to be hooked into your framework. The main forms that you will need to connect with are listed below.

Alternatively, you can download Sutra CMS with Data Mosaic's Data Sutra application platform to immediately have a standalone CMS application.

FILES

- LICENSE.txt
- README.txt
- sutra-cms_standalone.servoy
- sutra-cms.sql
- sutraCMS directory

1) LICENSE.txt

MIT license -- the most flexible and user friendly open source license available. Basically means use however you want, but just don't sue us :)

2) README.txt

This document containing basic instructions.

3) sutra-cms_standalone.servoy

Servoy install file with sample data. Includes the following modules:

	_dsa_mosaic_WEB_cms
	_dsa_mosaic_WEB_cms_blocks
	_dsa_mosaic_WEB_cms_connector
	_dsa_mosaic_WEB_cms_stacks
	_ds_CODE_resources

4) sutra-cms.sql

A MySQL dump file of the Sutra CMS sample data. Included just in case. Not sure how well it will work with PostgreSQL.

5) sutraCMS directory

Place this directory in Servoy's server ROOT directory:
	/Servoy/application_server/server/webapps/ROOT/sutraCMS


INSTALLATION

- Database connections required:
	- sutra_cms

- Plugins required
	- The Browser Suite:
	https://www.servoyforge.net/projects/browsersuite

- import the sutra-cms_standalone.servoy file

- place the sutraCMS directory in the ROOT directory


SERVER SETTINGS

- http://localhost:8080/servoy-admin/plugin-settings
	- mac: set file plugin default path to "/"
	- windows: set file plugin default path to "C:"

- if you did not install Servoy into a directory called "Servoy", in smart client go to the installation form and change the Servoy directory to the name you installed to.


TEST

- open browser page to:
	localhost:8080/sutraCMS/index.jsp?id=1

MAIN FORMS OF INTEREST

These forms are the main top level workflow forms that you will want to hook into your navigation system:

- WEB_0F_install
- WEB_0F_site
- WEB_0F_page
- WEB_0F_asset
- WEB_0F_block
- WEB_0F_theme
- WEB_0F_install

Additional forms of interest:

- WEB_0T_page (a treeview form organizing page records)
- WEB_TB__web_mode (a toolbar for page editing)


DOCUMENTATION

http://www.data-mosaic.com/sutra-cms
