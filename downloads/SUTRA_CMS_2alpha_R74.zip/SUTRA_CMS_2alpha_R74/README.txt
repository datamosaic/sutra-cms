INSTRUCTIONS

install instructions go here along with what to do with all files.

self-explanatory
- license
- readme

minimum install
- put sutra.jar in application_server/plugins directory
- import sutra.servoy including sample data

advanced options
- sutra.sql is dump file for metadata and sample crm data
- sutra_no_connector.servoy is for upgrade installs