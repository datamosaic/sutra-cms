<!-- onload method to trigger category totals script -->
<script class="javascript" type="text/javascript">
	totalPosts();  
</script>