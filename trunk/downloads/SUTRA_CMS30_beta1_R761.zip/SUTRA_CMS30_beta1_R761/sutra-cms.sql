-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.54


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema data_sutra_cms
--

CREATE DATABASE IF NOT EXISTS data_sutra_cms;
USE data_sutra_cms;
CREATE TABLE `web_area` (
  `id_area` varchar(50) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `area_name` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_version` varchar(50) DEFAULT NULL,
  `id_editable` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_area`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_asset` (
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `asset_extension` varchar(50) DEFAULT NULL,
  `tags` mediumtext,
  `asset_file_type` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `id_asset` varchar(50) NOT NULL,
  `asset_name` varchar(255) DEFAULT NULL,
  `thumbnail` longblob,
  `asset_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_asset`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_asset_instance` (
  `id_asset_instance` varchar(50) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `asset_title` varchar(255) DEFAULT NULL,
  `asset_size` int(11) DEFAULT NULL,
  `asset_directory` mediumtext,
  `description` mediumtext,
  `id_asset` varchar(50) DEFAULT NULL,
  `flag_initial` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_asset_instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_asset_instance_meta` (
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_asset_instance_meta` varchar(50) NOT NULL,
  `id_asset_instance` varchar(50) DEFAULT NULL,
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `data_type` varchar(50) DEFAULT NULL,
  `data_value_blob` longblob,
  PRIMARY KEY (`id_asset_instance_meta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_attribute` (
  `id_attribute` varchar(50) NOT NULL,
  `attribute_key` varchar(255) DEFAULT NULL,
  `attribute_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_site_attribute` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block` (
  `id_block` varchar(50) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_block_type` varchar(50) DEFAULT NULL,
  `id_block_display` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `scope_type` int(11) DEFAULT NULL,
  `block_name` varchar(255) DEFAULT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_block`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_action_client` (
  `id_block_action_client` varchar(50) NOT NULL,
  `id_block_type` varchar(50) DEFAULT NULL,
  `input_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_block_action_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_action_web` (
  `id_block_type` varchar(50) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `flag_default` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_action_web` varchar(50) NOT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_block_action_web`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_configure` (
  `id_block_type` varchar(50) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_configure` varchar(50) NOT NULL,
  `column_name` varchar(50) DEFAULT NULL,
  `column_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_block_configure`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_data` (
  `id_block_data` varchar(50) NOT NULL,
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_block_version` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_block_data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_data_configure` (
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_block_version` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_data_configure` varchar(50) NOT NULL,
  PRIMARY KEY (`id_block_data_configure`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_data_response` (
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_data_response` varchar(50) NOT NULL,
  `id_block_version` varchar(50) DEFAULT NULL,
  `id_block` varchar(50) DEFAULT NULL,
  `id_session_access` varchar(50) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `id_instance` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_block_data_response`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_display` (
  `id_block_display` varchar(50) NOT NULL,
  `id_block_type` varchar(50) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `flag_default` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_block_display`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_input` (
  `id_block_input` varchar(50) NOT NULL,
  `column_name` varchar(50) DEFAULT NULL,
  `column_type` varchar(10) DEFAULT NULL,
  `description` mediumtext,
  `id_block_type` varchar(50) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_block_input`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_response` (
  `column_name` varchar(50) DEFAULT NULL,
  `column_type` varchar(10) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_response` varchar(50) NOT NULL,
  `id_block_type` varchar(50) DEFAULT NULL,
  `description` mediumtext,
  PRIMARY KEY (`id_block_response`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_type` (
  `id_block_type` varchar(50) NOT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `block_name` varchar(255) DEFAULT NULL,
  `block_description` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `form_name_display` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_block_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_block_version` (
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_block_type` varchar(50) DEFAULT NULL,
  `id_block_display` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `flag_active` int(11) DEFAULT NULL,
  `id_block_version` varchar(50) NOT NULL,
  `id_block` varchar(50) DEFAULT NULL,
  `version_number` int(11) DEFAULT NULL,
  `version_name` varchar(255) DEFAULT NULL,
  `flag_lock` int(11) DEFAULT NULL,
  `version_description` mediumtext,
  PRIMARY KEY (`id_block_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_editable` (
  `id_editable` varchar(50) NOT NULL,
  `id_layout` varchar(50) DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `editable_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `flag_new_block` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_editable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_editable_default` (
  `id_editable_default` varchar(50) NOT NULL,
  `id_editable` varchar(50) DEFAULT NULL,
  `id_block_type` varchar(50) DEFAULT NULL,
  `id_block_display` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `id_block` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_editable_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_group` (
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_group` varchar(50) NOT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  `url_param` int(11) DEFAULT NULL,
  `id_site_group` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_install` (
  `id_install` varchar(50) NOT NULL,
  `directory_windows` varchar(255) DEFAULT NULL,
  `directory_mac` varchar(255) DEFAULT NULL,
  `directory_linux` varchar(255) DEFAULT NULL,
  `type_server` varchar(50) DEFAULT NULL,
  `rewrite_enabled` int(11) DEFAULT NULL,
  `url_install` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_install`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `web_install` VALUES  ('49CA9267-1301-4901-A806-F05CDE1E161B','C:/Program FIles/Servoy','/Applications/Servoy','/opt/servoy','Mac',NULL,'servlets:8080');
CREATE TABLE `web_language` (
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_language` varchar(50) NOT NULL,
  `id_site_language` varchar(50) DEFAULT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `url_param` int(11) DEFAULT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_layout` (
  `id_layout` varchar(50) NOT NULL,
  `id_theme` varchar(50) DEFAULT NULL,
  `layout_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `layout_path` mediumtext,
  `organization_id` int(11) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_layout`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_log` (
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_log` varchar(50) NOT NULL,
  `log_type` varchar(255) DEFAULT NULL,
  `log_message` mediumtext,
  `id_site` varchar(50) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `record_id` varchar(50) DEFAULT NULL,
  `record_table` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_meta_data` (
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `id_language` varchar(50) DEFAULT NULL,
  `id_meta_data` varchar(50) NOT NULL,
  PRIMARY KEY (`id_meta_data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_multisite` (
  `id_multisite` varchar(50) NOT NULL,
  `multisite_key` varchar(50) DEFAULT NULL,
  `description` mediumtext,
  `name` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id_multisite`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_page` (
  `id_page` varchar(50) NOT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `order_by` int(11) DEFAULT NULL,
  `parent_id_page` varchar(50) DEFAULT NULL,
  `description` mediumtext,
  `flag_publish` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `page_type` int(11) DEFAULT NULL,
  `flag_ssl` int(11) DEFAULT NULL,
  `title_override` varchar(255) DEFAULT NULL,
  `page_link` mediumtext,
  `page_link_internal` varchar(50) DEFAULT NULL,
  `multisite_page_key` varchar(50) DEFAULT NULL,
  `url_param` int(11) DEFAULT NULL,
  `flag_folder_children` int(11) DEFAULT NULL,
  `flag_folder_skip` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_page`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_path` (
  `id_path` varchar(50) NOT NULL,
  `path` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `id_language` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_platform` (
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_platform` varchar(50) NOT NULL,
  `id_site_platform` varchar(50) DEFAULT NULL,
  `id_theme` varchar(50) DEFAULT NULL,
  `id_layout` varchar(50) DEFAULT NULL,
  `url_param` int(11) DEFAULT NULL,
  `id_page` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_scope` (
  `id_area` varchar(50) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_scope` varchar(50) NOT NULL,
  `id_block` varchar(50) DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `flag_active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_session` (
  `id_session` varchar(50) NOT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_login` varchar(50) DEFAULT NULL,
  `login_created` datetime DEFAULT NULL,
  `id_site_group` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_session`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_session_access` (
  `id_session_access` varchar(50) NOT NULL,
  `id_session` varchar(50) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `referrer` longtext,
  `id_page` varchar(50) DEFAULT NULL,
  `url` longtext,
  `rec_created_client` datetime DEFAULT NULL,
  `rec_modified_client` datetime DEFAULT NULL,
  `access_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_session_access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_session_data` (
  `id_session_data` varchar(50) NOT NULL,
  `id_session` varchar(50) DEFAULT NULL,
  `data_key` mediumtext,
  `data_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id_session_data`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_site` (
  `id_site` varchar(50) NOT NULL,
  `site_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `site_name_publish_flag` int(11) DEFAULT NULL,
  `site_name_publish_separator` varchar(10) DEFAULT NULL,
  `pref_links` varchar(50) DEFAULT NULL,
  `id_page__home` varchar(50) DEFAULT NULL,
  `id_page__error` varchar(50) DEFAULT NULL,
  `google_tracking_code` varchar(50) DEFAULT NULL,
  `directory` mediumtext,
  `multisite_key` varchar(50) DEFAULT NULL,
  `id_page__home__display` varchar(255) DEFAULT NULL,
  `id_page__error__display` varchar(255) DEFAULT NULL,
  `flag_auto_publish` int(11) DEFAULT NULL,
  `flag_session` int(11) DEFAULT NULL,
  `url_servlet` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_site`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_site_attribute` (
  `id_site_attribute` varchar(50) NOT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `attribute_key` varchar(255) DEFAULT NULL,
  `attribute_value` mediumtext,
  `organization_id` int(11) DEFAULT NULL,
  `attribute_description` mediumtext,
  PRIMARY KEY (`id_site_attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_site_group` (
  `id_site_group` varchar(50) NOT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_site_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_site_language` (
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_site_language` varchar(50) NOT NULL,
  `language_name` varchar(255) DEFAULT NULL,
  `language_code` varchar(10) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `directory` varchar(255) DEFAULT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_site_language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_site_platform` (
  `id_site_platform` varchar(50) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `platform_name` varchar(255) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  `id_theme` varchar(50) DEFAULT NULL,
  `id_layout` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_site_platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_tag` (
  `id_tag` varchar(50) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `tag_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_theme` (
  `id_theme` varchar(50) NOT NULL,
  `theme_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `theme_directory` mediumtext,
  `organization_id` int(11) DEFAULT NULL,
  `id_site` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_theme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_user` (
  `id_user` varchar(50) NOT NULL,
  `name_first` varchar(255) DEFAULT NULL,
  `name_last` varchar(255) DEFAULT NULL,
  `name_formatted` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_verified` varchar(255) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `name_display` varchar(255) DEFAULT NULL,
  `name_username` varchar(255) DEFAULT NULL,
  `openid_provider` varchar(255) DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `web_version` (
  `id_version` varchar(50) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `version_number` int(11) DEFAULT NULL,
  `version_name` varchar(255) DEFAULT NULL,
  `flag_active` int(11) DEFAULT NULL,
  `version_description` mediumtext,
  `flag_lock` int(11) DEFAULT NULL,
  `id_platform` varchar(50) NOT NULL DEFAULT '',
  `id_language` varchar(50) NOT NULL DEFAULT '',
  `id_group` varchar(50) NOT NULL DEFAULT '',
  `url_param` int(11) DEFAULT NULL,
  `id_theme` varchar(50) DEFAULT NULL,
  `id_layout` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
