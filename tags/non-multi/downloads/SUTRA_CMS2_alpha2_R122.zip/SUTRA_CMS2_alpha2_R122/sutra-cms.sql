-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.52


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema cms_opensource_sutra_cms
--

CREATE DATABASE IF NOT EXISTS cms_opensource_sutra_cms;
USE cms_opensource_sutra_cms;
CREATE TABLE `web_area` (
  `id_area` int(11) NOT NULL,
  `id_page` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `area_name` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_version` int(11) DEFAULT NULL,
  `id_group` int(11) DEFAULT NULL,
  `id_editable` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_area`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_area` VALUES  (1,1,'2011-02-09 17:03:09',NULL,1,'Title',1,1,1,1),
 (2,1,'2011-02-09 17:03:09',NULL,2,'Head',1,1,1,2),
 (3,1,'2011-02-09 17:03:09',NULL,3,'Left Column',1,1,1,3),
 (4,1,'2011-02-09 17:03:09','2011-02-21 12:46:26',5,'Right Column',1,1,1,4),
 (5,1,'2011-02-09 17:03:09','2011-02-21 12:46:26',4,'Main',1,1,1,5),
 (6,1,'2011-02-09 17:03:09',NULL,6,'Foot',1,1,1,6),
 (13,3,'2011-02-09 17:19:05',NULL,1,'Title',1,3,1,1),
 (14,3,'2011-02-09 17:19:05',NULL,2,'Head',1,3,1,2),
 (15,3,'2011-02-09 17:19:05',NULL,3,'Left Column',1,3,1,3),
 (16,3,'2011-02-09 17:19:05','2011-02-21 12:15:49',5,'Right Column',1,3,1,4),
 (17,3,'2011-02-09 17:19:05','2011-02-21 12:15:49',4,'Main',1,3,1,5),
 (18,3,'2011-02-09 17:19:05',NULL,6,'Foot',1,3,1,6),
 (19,NULL,'2011-02-21 12:11:42',NULL,1,'Title',1,NULL,1,1),
 (20,NULL,'2011-02-21 12:11:42',NULL,2,'Head',1,NULL,1,2),
 (21,NULL,'2011-02-21 12:11:42',NULL,3,'Left Column',1,NULL,1,3),
 (22,NULL,'2011-02-21 12:11:42',NULL,4,'Right Column',1,NULL,1,4),
 (23,NULL,'2011-02-21 12:11:42',NULL,5,'Main',1,NULL,1,5),
 (24,NULL,'2011-02-21 12:11:42',NULL,6,'Foot',1,NULL,1,6),
 (31,NULL,'2011-02-21 12:12:51',NULL,1,'Title',1,NULL,1,1),
 (32,NULL,'2011-02-21 12:12:51',NULL,2,'Head',1,NULL,1,2),
 (33,NULL,'2011-02-21 12:12:51',NULL,3,'Left Column',1,NULL,1,3),
 (34,NULL,'2011-02-21 12:12:51',NULL,4,'Main',1,NULL,1,5),
 (35,NULL,'2011-02-21 12:12:51',NULL,5,'Right Column',1,NULL,1,4),
 (36,NULL,'2011-02-21 12:12:51',NULL,6,'Foot',1,NULL,1,6),
 (37,NULL,'2011-02-21 12:12:55',NULL,1,'Title',1,NULL,1,1),
 (38,NULL,'2011-02-21 12:12:55',NULL,2,'Head',1,NULL,1,2),
 (39,NULL,'2011-02-21 12:12:55',NULL,3,'Left Column',1,NULL,1,3),
 (40,NULL,'2011-02-21 12:12:55',NULL,4,'Main',1,NULL,1,5),
 (41,NULL,'2011-02-21 12:12:55',NULL,5,'Right Column',1,NULL,1,4),
 (42,NULL,'2011-02-21 12:12:55',NULL,6,'Foot',1,NULL,1,6),
 (43,4,'2011-02-21 12:13:01','2011-02-21 12:14:40',1,'Title',1,4,1,1),
 (44,4,'2011-02-21 12:13:01','2011-02-21 12:14:40',2,'Head',1,4,1,2),
 (45,4,'2011-02-21 12:13:01','2011-02-21 12:14:40',3,'Left Column',1,4,1,3),
 (47,4,'2011-02-21 12:13:01','2011-02-21 13:56:25',5,'Right Column',1,4,1,4),
 (48,4,'2011-02-21 12:13:01','2011-02-21 13:56:25',6,'Foot',1,4,1,6),
 (52,NULL,'2011-02-21 12:47:02',NULL,1,'Title',1,NULL,1,1),
 (53,NULL,'2011-02-21 12:47:02',NULL,2,'Head',1,NULL,1,2),
 (54,NULL,'2011-02-21 12:47:02',NULL,3,'Left Column',1,NULL,1,3),
 (55,NULL,'2011-02-21 12:47:02',NULL,4,'Main',1,NULL,1,5),
 (56,NULL,'2011-02-21 12:47:02',NULL,5,'Right Column',1,NULL,1,4),
 (57,NULL,'2011-02-21 12:47:02',NULL,6,'Foot',1,NULL,1,6),
 (58,4,'2011-02-21 13:56:25',NULL,4,'Main',1,4,1,5);
CREATE TABLE `web_asset` (
  `id_asset` int(11) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_site` int(11) DEFAULT NULL,
  `asset_extension` varchar(50) DEFAULT NULL,
  `asset_title` varchar(255) DEFAULT NULL,
  `asset_size` int(11) DEFAULT NULL,
  `asset_type` varchar(50) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `directory` varchar(255) DEFAULT NULL,
  `tags` mediumtext,
  `asset_thumbnail` longblob,
  `asset_file_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_asset`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_attribute` (
  `id_attribute` int(11) NOT NULL,
  `attribute_key` varchar(255) DEFAULT NULL,
  `attribute_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_site_attribute` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_block` (
  `id_block` int(11) NOT NULL,
  `id_area` int(11) DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `block_data` mediumtext,
  `id_block_type` int(11) DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `id_block_display` int(11) DEFAULT NULL,
  `params` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_scrapbook` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_block`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block` VALUES  (1,1,NULL,'2011-02-09 17:03:09',NULL,NULL,2,1,2,NULL,1,NULL),
 (2,2,NULL,'2011-02-09 17:03:09',NULL,NULL,2,1,2,NULL,1,NULL),
 (3,3,NULL,'2011-02-09 17:03:09',NULL,NULL,2,1,2,NULL,1,NULL),
 (4,4,NULL,'2011-02-09 17:03:09',NULL,NULL,2,1,2,NULL,1,NULL),
 (5,5,NULL,'2011-02-09 17:03:09',NULL,NULL,2,1,2,NULL,1,NULL),
 (6,6,NULL,'2011-02-09 17:03:09','2011-02-10 15:59:46',NULL,2,2,2,NULL,1,NULL),
 (7,3,NULL,'2011-02-09 17:10:16',NULL,NULL,2,2,2,NULL,1,NULL),
 (8,4,NULL,'2011-02-09 17:10:52',NULL,NULL,2,2,2,NULL,1,NULL),
 (9,5,NULL,'2011-02-09 17:11:14',NULL,NULL,2,2,2,NULL,1,NULL),
 (16,13,NULL,'2011-02-09 17:19:05',NULL,NULL,2,1,2,NULL,1,NULL),
 (17,14,NULL,'2011-02-09 17:19:05',NULL,NULL,2,1,2,NULL,1,NULL),
 (18,15,NULL,'2011-02-09 17:19:05',NULL,NULL,2,1,2,NULL,1,NULL),
 (19,16,NULL,'2011-02-09 17:19:05',NULL,NULL,2,1,2,NULL,1,NULL),
 (20,17,NULL,'2011-02-09 17:19:05',NULL,NULL,2,1,2,NULL,1,NULL),
 (21,18,NULL,'2011-02-09 17:19:05',NULL,NULL,2,1,2,NULL,1,NULL),
 (28,6,NULL,'2011-02-10 15:59:43','2011-02-10 15:59:46',NULL,2,1,2,NULL,1,NULL),
 (29,23,NULL,'2011-02-21 12:11:42',NULL,NULL,2,1,2,NULL,1,NULL),
 (31,34,NULL,'2011-02-21 12:12:51',NULL,NULL,2,1,2,NULL,1,NULL),
 (32,40,NULL,'2011-02-21 12:12:55',NULL,NULL,2,1,2,NULL,1,NULL),
 (37,55,NULL,'2011-02-21 12:47:02',NULL,NULL,2,1,2,NULL,1,NULL),
 (38,43,NULL,'2011-02-21 13:56:17',NULL,NULL,2,1,2,NULL,1,NULL);
CREATE TABLE `web_block_action_client` (
  `id_block_action_client` int(11) NOT NULL,
  `id_block_type` int(11) DEFAULT NULL,
  `input_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `description` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_block_action_client`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block_action_client` VALUES  (6,2,'Reset','BLOCK_reset',NULL,'2011-02-04 21:04:08',NULL,1,NULL,'Block'),
 (7,2,'Cancel','BLOCK_cancel',NULL,'2011-02-04 21:04:08',NULL,1,NULL,'Block'),
 (8,2,'Save','BLOCK_save',NULL,'2011-02-04 21:04:08',NULL,1,NULL,'Block'),
 (9,2,'Insert Image','BLOCK_insert_image',NULL,'2011-02-04 21:04:08',NULL,1,NULL,'Block'),
 (10,2,'Popup Test','PAGE_popup_test',NULL,'2011-02-04 21:04:08','2011-02-18 16:04:42',1,NULL,'Page');
CREATE TABLE `web_block_action_web` (
  `id_block_type` int(11) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `flag_default` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_action_web` int(11) NOT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_block_action_web`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block_action_web` VALUES  (2,'Test','WEB_test',NULL,NULL,NULL,NULL,1,1,NULL,NULL);
CREATE TABLE `web_block_configure` (
  `id_block_type` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_configure` int(11) NOT NULL,
  `column_name` varchar(50) DEFAULT NULL,
  `column_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_block_configure`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block_configure` VALUES  (2,'2011-02-18 18:07:12','2011-02-18 18:07:22',NULL,1,1,'config_test','TEXT');
CREATE TABLE `web_block_data` (
  `id_block_data` int(11) NOT NULL,
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `id_area` int(11) DEFAULT NULL,
  `id_block` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_block_data`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block_data` VALUES  (1,'Content','<h1>Sandbox Theme</h1>','2011-02-09 17:03:09','2011-02-18 16:39:34',NULL,NULL,1,1),
 (2,'Content','<p>Template for demoing various features and blocks as they are implemented. Duplicating this theme and modifying it for your own use is also another possibility although we recommend the OOCSS theme as a more robust starting point.</p>','2011-02-09 17:03:09','2011-02-09 17:03:59',NULL,NULL,2,1),
 (3,'Content','<h2>Left Column</h2>','2011-02-09 17:03:09','2011-02-09 17:10:25',NULL,NULL,3,1),
 (4,'Content','<h2>Right Column</h2>','2011-02-09 17:03:09','2011-02-09 17:10:49',NULL,NULL,4,1),
 (5,'Content','<h2>Main Column</h2>','2011-02-09 17:03:09','2011-02-09 17:11:11',NULL,NULL,5,1),
 (6,'Content','<p>Copyright &copy; 2011 <a title=\"Data Mosaic\" href=\"http://www.data-mosaic.com/\" target=\"_blank\">Data Mosaic</a>, <a title=\"Open Source Initiative: MIT\" href=\"http://www.opensource.org/licenses/mit-license\" target=\"_blank\">MIT Licensed</a></p>','2011-02-09 17:03:09','2011-02-13 22:05:27',NULL,NULL,6,1),
 (7,'Content','<p><b>v1 (feb 9, 2011)</b><br />Content block only. Demo various features of tinyMCE.</p>','2011-02-09 17:10:16','2011-02-09 17:25:10',NULL,NULL,7,1),
 (8,'Content','<p><b>Internal page links:</b></p>\r\n<p><a href=\"{DS:ID_3}\">Directory 1 Page 1</a><br /><a href=\"{DS:ID_4}\">Directory 2 Page 2</a></p>\r\n<p><b>List:</b></p>\r\n<ul>\r\n<li>item 1</li>\r\n<li>item 2</li>\r\n<li>item 3</li>\r\n</ul>','2011-02-09 17:10:52','2011-02-09 17:26:12',NULL,NULL,8,1),
 (9,'Content','<p>Just the good ol\' boys, never meanin\' no harm. Beats all you\'ve ever saw, been in trouble with the law since the day they was born. Straight\'nin\' the curve, flat\'nin\' the hills. Someday the mountain might get \'em, but the law never will. Makin\' their way, the only way they know how, that\'s just a little bit more than the law will allow. Just good ol\' boys, wouldn\'t change if they could, fightin\' the system like a true modern day Robin Hood.<br /><br />There\'s a voice that keeps on calling me. Down the road, that\'s where I\'ll always be. Every stop I make, I make a new friend. Can\'t stay for long, just turn around and I\'m gone again. Maybe tomorrow, I\'ll want to settle down, Until tomorrow, I\'ll just keep moving on.<br /><br />Knight Rider, a shadowy flight into the dangerous world of a man who does not exist. Michael Knight, a young loner on a crusade to champion the cause of the innocent, the helpless in a world of criminals who operate above the law.</p>\r\n<p>Source: <a href=\"http://www.malevole.com/mv/misc/text/\">http://www.malevole.com/mv/misc/text/</a></p>','2011-02-09 17:11:14','2011-02-09 17:16:26',NULL,NULL,9,1),
 (16,'Content',NULL,'2011-02-09 17:19:05',NULL,NULL,NULL,16,1),
 (17,'Content',NULL,'2011-02-09 17:19:05',NULL,NULL,NULL,17,1),
 (18,'Content',NULL,'2011-02-09 17:19:05',NULL,NULL,NULL,18,1),
 (19,'Content','<p><a href=\"{DS:ID_1}\">Home page</a></p>','2011-02-09 17:19:05','2011-02-09 17:20:53',NULL,NULL,19,1),
 (20,'Content',NULL,'2011-02-09 17:19:05',NULL,NULL,NULL,20,1),
 (21,'Content','','2011-02-09 17:19:05','2011-02-13 15:23:18',NULL,NULL,21,1),
 (28,'Content','<h2>Footer</h2>','2011-02-10 15:59:43','2011-02-10 15:59:54',NULL,NULL,28,1),
 (29,'Content',NULL,'2011-02-21 12:11:42',NULL,NULL,NULL,29,1),
 (31,'Content',NULL,'2011-02-21 12:12:51',NULL,NULL,NULL,31,1),
 (32,'Content',NULL,'2011-02-21 12:12:55',NULL,NULL,NULL,32,1),
 (37,'Content',NULL,'2011-02-21 12:47:02',NULL,NULL,NULL,37,1),
 (38,'Content','<p><a href=\"{DS:ID_1}\">Home page</a></p>','2011-02-21 13:56:17','2011-02-21 13:56:47',NULL,NULL,38,1);
CREATE TABLE `web_block_data_response` (
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_data_response` int(11) NOT NULL,
  `id_block` int(11) DEFAULT NULL,
  `id_session_access` int(11) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_block_data_response`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_block_display` (
  `id_block_display` int(11) NOT NULL,
  `id_block_type` int(11) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `flag_default` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_block_display`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block_display` VALUES  (2,2,'Default','VIEW_default','2011-02-04 21:04:08','2011-02-18 18:06:51','',1,1,NULL);
CREATE TABLE `web_block_input` (
  `id_block_input` int(11) NOT NULL,
  `column_name` varchar(50) DEFAULT NULL,
  `column_type` varchar(10) DEFAULT NULL,
  `description` mediumtext,
  `id_block_type` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_block_input`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block_input` VALUES  (2,'Content','TEXT','',2,'2011-02-04 21:04:08','2011-02-18 18:06:54',1);
CREATE TABLE `web_block_response` (
  `column_name` varchar(50) DEFAULT NULL,
  `column_type` varchar(10) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_block_response` int(11) NOT NULL,
  `id_block_type` int(11) DEFAULT NULL,
  `description` mediumtext,
  PRIMARY KEY (`id_block_response`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `web_block_response` VALUES  ('response_test','TEXT','2011-02-18 18:07:24','2011-02-18 18:07:31',NULL,1,1,2,NULL);
CREATE TABLE `web_block_type` (
  `id_block_type` int(11) NOT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `block_name` varchar(255) DEFAULT NULL,
  `block_description` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_site` int(11) DEFAULT NULL,
  `form_name_display` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_block_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_block_type` VALUES  (2,'WEB_0F__content','Content','Generic freeform content. HTML/CSS for structure and formatting.\n\nUses TinyMCE to edit content.','2011-02-04 21:04:08',NULL,NULL,1,1,'WEB_0F__content_view');
CREATE TABLE `web_editable` (
  `id_editable` int(11) NOT NULL,
  `id_layout` int(11) DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `editable_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `flag_new_block` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_editable`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_editable` VALUES  (1,1,1,'Title','2011-02-09 17:01:05','2011-02-20 15:34:25',1,1),
 (2,1,2,'Head','2011-02-09 17:01:05','2011-02-21 13:55:23',1,1),
 (3,1,3,'Left Column','2011-02-09 17:01:05','2011-02-21 13:55:23',1,1),
 (4,1,5,'Right Column','2011-02-09 17:01:05','2011-02-21 13:55:24',1,1),
 (5,1,4,'Main','2011-02-09 17:01:05','2011-02-21 13:55:24',1,1),
 (6,1,6,'Foot','2011-02-09 17:01:05','2011-02-20 15:34:25',1,1);
CREATE TABLE `web_editable_default` (
  `id_editable_default` int(11) NOT NULL,
  `id_editable` int(11) DEFAULT NULL,
  `id_block_type` int(11) DEFAULT NULL,
  `id_block_display` int(11) DEFAULT NULL,
  `params` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `id_scrapbook` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_editable_default`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_editable_default` VALUES  (1,5,2,2,NULL,1,'2011-02-21 11:44:48',NULL,1,NULL);
CREATE TABLE `web_group` (
  `id_group` int(11) NOT NULL,
  `id_site` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_group`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_group` VALUES  (1,1,'2011-02-04 20:45:39','2011-02-04 20:49:23',1,'Everybody');
CREATE TABLE `web_install` (
  `id_install` int(11) NOT NULL,
  `directory_windows` varchar(255) DEFAULT NULL,
  `directory_mac` varchar(255) DEFAULT NULL,
  `directory_linux` varchar(255) DEFAULT NULL,
  `type_server` varchar(50) DEFAULT NULL,
  `rewrite_enabled` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_install`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_install` VALUES  (1,'C:/PROGRA~1/SERVOY','/Applications/Servoy','/opt/servoy','Windows',NULL);
CREATE TABLE `web_layout` (
  `id_layout` int(11) NOT NULL,
  `id_theme` int(11) DEFAULT NULL,
  `layout_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `layout_path` text,
  `organization_id` int(11) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_layout`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_layout` VALUES  (1,2,'default','2011-02-09 17:01:05',NULL,NULL,'default.jsp',1,1);
CREATE TABLE `web_page` (
  `id_page` int(11) NOT NULL,
  `id_site` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `id_theme` int(11) DEFAULT NULL,
  `id_theme_layout` int(11) DEFAULT NULL,
  `order_by` int(11) DEFAULT NULL,
  `parent_id_page` int(11) DEFAULT NULL,
  `description` mediumtext,
  `flag_publish` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `page_type` int(11) DEFAULT NULL,
  `flag_ssl` int(11) DEFAULT NULL,
  `keywords` mediumtext,
  `title_override` varchar(255) DEFAULT NULL,
  `page_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_page`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_page` VALUES  (1,1,'2011-02-09 17:02:48','2011-02-21 12:16:13','Home',2,1,1,0,NULL,1,1,0,NULL,NULL,NULL,NULL),
 (2,1,'2011-02-09 17:18:13','2011-02-21 12:47:12','Directory 1',2,1,2,0,NULL,1,1,1,NULL,NULL,NULL,NULL),
 (3,1,'2011-02-09 17:18:51','2011-02-09 17:19:12','Directory 1 Page 1',2,1,1,2,NULL,1,1,0,NULL,NULL,NULL,NULL),
 (4,1,'2011-02-09 17:19:16','2011-02-09 17:19:26','Directory 1 Page 2',2,1,2,2,NULL,1,1,0,NULL,NULL,NULL,NULL);
CREATE TABLE `web_path` (
  `id_path` int(11) NOT NULL,
  `path` text,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  `id_site` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_path`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_path` VALUES  (1,'home','2011-02-09 17:03:09',NULL,1,1,1,1),
 (2,'collection','2011-02-09 17:18:25',NULL,2,1,1,1),
 (3,'directory-1-page-1','2011-02-09 17:19:05',NULL,3,1,1,1),
 (4,'directory-1-page-2','2011-02-09 17:19:24',NULL,4,1,1,1);
CREATE TABLE `web_scrapbook` (
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `block_data` mediumtext,
  `id_block_type` int(11) DEFAULT NULL,
  `row_order` int(11) DEFAULT NULL,
  `id_block_display` int(11) DEFAULT NULL,
  `params` varchar(255) DEFAULT NULL,
  `id_scrapbook` int(11) NOT NULL,
  `scrapbook_name` varchar(255) DEFAULT NULL,
  `organization_id` varchar(50) DEFAULT NULL,
  `id_site` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_scrapbook`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_scrapbook_data` (
  `data_key` varchar(255) DEFAULT NULL,
  `data_value` mediumtext,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_scrapbook_data` int(11) NOT NULL,
  `id_scrapbook` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_scrapbook_data`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_session` (
  `id_session` int(11) NOT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_session`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_session_access` (
  `id_session_access` int(11) NOT NULL,
  `id_session` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `referrer` text,
  `id_page` int(11) DEFAULT NULL,
  `url` text,
  PRIMARY KEY (`id_session_access`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_site` (
  `id_site` int(11) NOT NULL,
  `site_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_organization` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `site_name_publish_flag` int(11) DEFAULT NULL,
  `site_name_publish_separator` varchar(10) DEFAULT NULL,
  `pref_links` varchar(50) DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `id_page_error` int(11) DEFAULT NULL,
  `google_tracking_code` varchar(50) DEFAULT NULL,
  `url_2` varchar(255) DEFAULT NULL,
  `flag_logging` int(11) DEFAULT NULL,
  `directory` mediumtext,
  PRIMARY KEY (`id_site`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_site` VALUES  (1,'Sandbox','2011-02-04 20:23:56','2011-02-14 22:27:40',NULL,'localhost',1,1,NULL,'Index',1,NULL,NULL,NULL,0,'default');
CREATE TABLE `web_site_attribute` (
  `id_site_attribute` int(11) NOT NULL,
  `id_site` int(11) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `attribute_key` varchar(255) DEFAULT NULL,
  `attribute_value` mediumtext,
  `organization_id` int(11) DEFAULT NULL,
  `attribute_description` mediumtext,
  PRIMARY KEY (`id_site_attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_tag` (
  `id_tag` int(11) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `tag_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_theme` (
  `id_theme` int(11) NOT NULL,
  `theme_name` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `description` mediumtext,
  `activated` int(11) DEFAULT NULL,
  `theme_directory` text,
  `owner` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `id_site` int(11) DEFAULT NULL,
  `flag_default` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_theme`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_theme` VALUES  (2,'Sandbox','2011-02-09 17:01:05','2011-02-09 17:01:51','Template for demoing various features and blocks as they are implemented. Duplicating this theme and modifying it for your own use is also another possibility although we recommend the OOCSS theme as a more robust starting point.',1,'sandbox',NULL,1,1,1);
CREATE TABLE `web_user` (
  `id_user` int(11) NOT NULL,
  `name_first` varchar(255) DEFAULT NULL,
  `name_last` varchar(255) DEFAULT NULL,
  `name_formatted` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `email_verified` varchar(255) DEFAULT NULL,
  `address_country` varchar(100) DEFAULT NULL,
  `name_display` varchar(255) DEFAULT NULL,
  `name_username` varchar(255) DEFAULT NULL,
  `openid_provider` varchar(255) DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE `web_version` (
  `id_version` int(11) NOT NULL,
  `rec_created` datetime DEFAULT NULL,
  `rec_modified` datetime DEFAULT NULL,
  `id_page` int(11) DEFAULT NULL,
  `id_site` int(11) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `version_number` int(11) DEFAULT NULL,
  `version_name` varchar(255) DEFAULT NULL,
  `flag_active` int(11) DEFAULT NULL,
  `version_description` varchar(255) DEFAULT NULL,
  `flag_edit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `web_version` VALUES  (1,'2011-02-09 17:02:48','2011-02-18 04:34:45',1,NULL,1,1,NULL,1,NULL,1),
 (2,'2011-02-09 17:18:13','2011-02-09 17:18:28',2,NULL,1,1,NULL,1,NULL,0),
 (3,'2011-02-09 17:18:51','2011-02-09 17:19:10',3,NULL,1,1,NULL,1,NULL,1),
 (4,'2011-02-09 17:19:16','2011-02-09 17:19:29',4,NULL,1,1,NULL,1,NULL,1);



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
