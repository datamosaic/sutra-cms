This is a combo installer of Data Sutra application platform with Sutra CMS. This results in a complete solution for running the Sutra CMS.

Note that Data Sutra will be running in trial mode. This allows you to work with all functionality in Servoy Developer but doesn't allow you to deploy to Servoy Server. When you want to deploy, you can purchase a license from us over at data-mosaic.com.

Alternatively, you can download Sutra CMS by itself (MIT license) and include in your application framework.

FILES

- LICENSE_CMS.txt
- LICENSE.txt
- README.txt
- sutra-cms_with_framework.servoy
- sutra.jar
- sutra-cms.sql
- sutraCMS directory

1) LICENSE_CMS.txt

MIT license -- the most flexible and user friendly open source license available. Basically means use however you want, but just don't sue us :)

2) LICENSE.txt

License for Data Sutra application platform.

2) README.txt

This document containing basic instructions.

3) sutra-cms_with_framework.servoy

Servoy install file with sample and meta data. Includes everything needed to be up and running.

4) sutra-cms.sql

A MySQL dump file of all data. Included just in case. Not sure how well it will work with PostgreSQL.

5) sutra.jar

Plugin needed to run Data Sutra. Place in ../Servoy/application_server/plugins directory.

6) sutraCMS directory

Place this directory in Servoy's server ROOT directory:
	../Servoy/application_server/server/webapps/ROOT/sutraCMS


INSTALLATION

- Database connections required:
	- sutra_cms
	- sutra_example
	- sutra

- Plugins required
	- The Browser Suite:
	https://www.servoyforge.net/projects/browsersuite
	- sutra.jar

- import the sutra-cms_with_framework.servoy file

- place the sutraCMS directory in the ROOT directory


TEST

- open browser page to:
	localhost:8080/sutraCMS/index.jsp?id=1


FEEDBACK

Google group: http://groups-sutra-cms.data-mosaic.com/


DOCUMENTATION

http://www.data-mosaic.com/sutra-cms
